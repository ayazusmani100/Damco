<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'slider' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Q1e}89MS;I+nW^aq~;V#nYYtP)5lV-9L1YmHB&srU3tg%S=qqBP4C5sKKRu_kZow' );
define( 'SECURE_AUTH_KEY',  'Q&}$p2oyJ{Jd#8[ARes!jZ7W}=2)1Q6z]A[9_~!;t&2)K*Obdk>I~:bx<;<`@QOI' );
define( 'LOGGED_IN_KEY',    ' YC+WvY>UZqr}yYC&N_@Q2lba%fL=ksre)jw>}*%lV9Jx%|_+DbCr&3cpw|$xNN1' );
define( 'NONCE_KEY',        '/h@46Hi--tS&:T&]GtDGDrpr$Hv]bJ_cF T<_ @&L]YjhI-yX$ZeHO*R{d:%wy&#' );
define( 'AUTH_SALT',        'GB;K@]]Fg(wWV#+Ghm~ch}C:<ts)7Za^ oD>JPb:NS ]{ui_iYd9ApMh!wi/iO|g' );
define( 'SECURE_AUTH_SALT', '*8#53i05k+^DK1JzTh6zOV8.W!HkQbnYE&pVZJ$-XQt6^.,l$4s$=27`;B?07lM/' );
define( 'LOGGED_IN_SALT',   '2#{W!&9)w]QfE|hJ~%6rkUifs&!qWqh<Z}Hl [h],21?Kn)K9^Hvz#eW7/4m1& {' );
define( 'NONCE_SALT',       'ah3miBV5%.ws/.bK8pN+C@b:gEK>aRX]sv(!i,<pnX<V,A4wh,<R47Xx`b@d&3E]' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
